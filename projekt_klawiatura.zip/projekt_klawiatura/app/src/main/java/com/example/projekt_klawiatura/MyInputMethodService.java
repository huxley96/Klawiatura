package com.example.projekt_klawiatura;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.inputmethodservice.InputMethodService;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.nfc.NfcAdapter;
import android.nfc.NfcManager;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

import static android.provider.Settings.ACTION_NFC_PAYMENT_SETTINGS;
import static androidx.core.app.ActivityCompat.*;
import static java.lang.Character.charCount;
import static java.lang.Character.toUpperCase;

public class MyInputMethodService extends InputMethodService implements KeyboardView.OnKeyboardActionListener {
    @Override
    public View onCreateInputView() {
        KeyboardView keyboardView = (KeyboardView) getLayoutInflater().inflate(R.layout.keyboard_view, null);
        Keyboard keyboard = new Keyboard(this, R.layout.number_pad);
        keyboardView.setKeyboard(keyboard);
        keyboardView.setOnKeyboardActionListener(this);
        return keyboardView;
    }

    public View onCreateInputView2() {
        KeyboardView keyboardView = (KeyboardView) getLayoutInflater().inflate(R.layout.keyboard_view, null);
        Keyboard keyboard = new Keyboard(this, R.layout.number_pad2);
        keyboardView.setKeyboard(keyboard);
        keyboardView.setOnKeyboardActionListener(this);
        return keyboardView;
    }
    public View onCreateInputView3() {
        KeyboardView keyboardView = (KeyboardView) getLayoutInflater().inflate(R.layout.keyboard_view, null);
        Keyboard keyboard = new Keyboard(this, R.layout.number_pad3);
        keyboardView.setKeyboard(keyboard);
        keyboardView.setOnKeyboardActionListener(this);
        return keyboardView;
    }


    @Override
    public void onPress(int primaryCode) {
    }

    @Override
    public void onRelease(int primaryCode) {
    }

    @Override
    public void onText(CharSequence text) {
    }

    @Override
    public void swipeLeft() {
    }

    @Override
    public void swipeRight() {
    }

    @Override
    public void swipeDown() {
    }

    @Override
    public void swipeUp() {
    }

    public void toastMsg(String msg) {

        Toast toast = Toast.makeText(this, msg, Toast.LENGTH_LONG);
        toast.show();

    }

    public void serwer(String tekst)
    {
        final BluetoothServerSocket mmServerSocket;
        BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        BluetoothServerSocket tmp = null;
        try {
            UUID uuid=UUID.fromString("ebe3a525-0cef-4907-94b0-e39e1255ce43");
            tmp = mBluetoothAdapter.listenUsingRfcommWithServiceRecord("Usługa witająca", uuid);
        } catch (IOException e) { }
        mmServerSocket = tmp;

        BluetoothSocket socket;
        while (true) {
            Log.d("INFO","czas");
            try {
                Log.d("INFO","Czekam na połączenie od clienta");
                socket = mmServerSocket.accept();
                Log.d("INFO","Mam clienta!");
                String text = "TOAST!";
                Toast.makeText(getApplicationContext(), text, 5).show();
                PrintWriter out = new PrintWriter(socket.getOutputStream(),true);
                out.println(tekst);
            } catch (IOException e) {
                break;

            }
            if (socket != null) {

                try {
                    mmServerSocket.close();


                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
        }






    }

    public void klient()
    {
        BluetoothAdapter ba1 = BluetoothAdapter.getDefaultAdapter();

        BluetoothDevice serwer = ba1.getRemoteDevice("AC:92:32:BF:95:4D".toString());
        BluetoothSocket mmSocket;
        BluetoothDevice mmDevice = serwer;

        BluetoothSocket tmp = null;

        try {
            UUID uuid = UUID.fromString("ebe3a525-0cef-4907-94b0-e39e1255ce43");
            tmp = serwer.createRfcommSocketToServiceRecord(uuid);
        } catch (Exception e) { }
        mmSocket = tmp;

        try {
            Log.d("INFO","Próba połączenia....");
            mmSocket.connect();
            Log.d("INFO","Połączono z serwerem!");
            BufferedReader in = new BufferedReader(new InputStreamReader(mmSocket.getInputStream()));
            String input = in.readLine();
            Log.d("INFO","Serwer mówi: "+input);

            InputConnection ic = getCurrentInputConnection();
            ic.commitText(input, 1);

        } catch (Exception ce) {
            try {
                mmSocket.close();
            } catch (Exception cle) { }
            return;
         }
    }






    public boolean onof()
    {
        boolean czy=false;

        NfcManager manager = (NfcManager) getApplicationContext().getSystemService(Context.NFC_SERVICE);
        NfcAdapter adapter = manager.getDefaultAdapter();

        if (adapter != null && adapter.isEnabled()) {
            czy=true;
        } else {
            czy=false;
        }
        return czy;
    }



    public static boolean powerNfc(boolean isOn, Context context) {
        boolean success = false;
        NfcAdapter nfcAdapter = NfcAdapter.getDefaultAdapter(context);

        if (nfcAdapter != null) {
            Class<?> NfcManagerClass;
            Method setNfcEnabled;

            try {

                NfcManagerClass = Class.forName(nfcAdapter.getClass().getName());
                setNfcEnabled = NfcManagerClass.getDeclaredMethod(isOn
                        ? "enable" : "disable");
                setNfcEnabled.setAccessible(true);
                success = (Boolean) setNfcEnabled.invoke(nfcAdapter);


            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }


        }

        return success;
    }



    BluetoothAdapter ba = BluetoothAdapter.getDefaultAdapter();





    public void saveFile(Context context, String fileName, String text){

        FileOutputStream fos = null;
        try {

            fos = context.openFileOutput(context.getFilesDir().getAbsolutePath() + "/" + fileName +".txt", Context.MODE_PRIVATE);
            Writer out = new OutputStreamWriter(fos);
            out.write(text);
            out.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }




    public void onKey(int primaryCode, int[] keyCodes) {

        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        CharSequence selectedText = ic.getSelectedText(0);


        AudioManager am = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
        am.playSoundEffect(AudioManager.FX_KEY_CLICK,1);

        switch (primaryCode) {

            case 1:

                ic.commitText("Custom txt", 1);




                break;


            case 61:


                //kamera







                Intent cam = new Intent("android.media.action.IMAGE_CAPTURE");
                cam.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(cam);

                break;


            case 3:
                //dzwiek

                MediaPlayer dzwiek=MediaPlayer.create(this,R.raw.dzwiek);
                dzwiek.start();
                break;


            case 4:


                String text = "TOAST!";


                Toast.makeText(getApplicationContext(), text, 5).show();
                break;


            case 15:
                // shift1


                setInputView(onCreateInputView2());






                break;

            case 99:
                // shift2


                setInputView(onCreateInputView3());






                break;

            case 6:
                //zapis pliku
                File file = new File(getFilesDir(), "file.txt");
                file.delete();
                try {
                    file.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                try (FileOutputStream stream = new FileOutputStream(file)) {
                    stream.write("File saved.".getBytes());
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }


                break;

            case 7:
                //czy nfc




                if (onof()==true){
                    Toast.makeText(getApplicationContext(), "on", 5).show();
                }   else {
                    Toast.makeText(getApplicationContext(), "off", 5).show();
                }


                break;

            case 8:
                //on  nfc




                Intent cfn = (new Intent(Settings.ACTION_NFC_SETTINGS));
                cfn.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(cfn);
                break;

            case 50:

                BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
                if (mBluetoothAdapter == null) {
                    toastMsg("BT don't supported!");
                } else if (!mBluetoothAdapter.isEnabled()) {
                    toastMsg("BT disabled!");
                } else {
                    toastMsg("BT enabled!");
                }
                break;








            case Keyboard.KEYCODE_DELETE:

                if (TextUtils.isEmpty(selectedText)) {
                    ic.deleteSurroundingText(1, 0);
                }

                else {

                    ic.commitText("", 1);
                }
                break;



            case 60:
                //serwer bluetooth
                serwer("Hello I'm Custom Keyboard!");
                break;
            case 32:
                //serwer bluetooth
                serwer("6000010000123");
                break;
            case 62:
                //serwer bluetooth
                serwer("6000010000124");
                break;
            case 64:
                setInputView(onCreateInputView());
                break;

            case 78:
                //klient bluetooth

                klient();


                break;



            default:

        }


    }}